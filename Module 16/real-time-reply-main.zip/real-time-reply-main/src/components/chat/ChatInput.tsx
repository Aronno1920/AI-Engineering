import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Send, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";

interface ChatInputProps {
  onSendMessage: (message: string, sessionId: string) => void;
  isLoading: boolean;
  sessionId: string;
  onSessionIdChange: (sessionId: string) => void;
}

export const ChatInput = ({ onSendMessage, isLoading, sessionId, onSessionIdChange }: ChatInputProps) => {
  const [message, setMessage] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim() && sessionId.trim() && !isLoading) {
      onSendMessage(message.trim(), sessionId.trim());
      setMessage("");
    }
  };

  return (
    <div className="border-t bg-chat-input p-4 space-y-3">
      <div className="flex gap-2">
        <Input
          placeholder="Session ID"
          value={sessionId}
          onChange={(e) => onSessionIdChange(e.target.value)}
          className="flex-1 bg-background border-chat-input-border"
          disabled={isLoading}
        />
      </div>
      <form onSubmit={handleSubmit} className="flex gap-2">
        <Input
          placeholder="Type your message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="flex-1 bg-background border-chat-input-border"
          disabled={isLoading}
        />
        <Button 
          type="submit" 
          disabled={!message.trim() || !sessionId.trim() || isLoading}
          className={cn(
            "shrink-0",
            isLoading && "cursor-not-allowed"
          )}
        >
          {isLoading ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Send className="h-4 w-4" />
          )}
        </Button>
      </form>
    </div>
  );
};