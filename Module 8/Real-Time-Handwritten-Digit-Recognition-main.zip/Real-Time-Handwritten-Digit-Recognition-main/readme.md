
Required Packages
!pip install flask tensorflow pillow numpy

## Real-Time Handwritten Digit Recognition

This project demonstrates real-time recognition of handwritten digits using a deep learning model with a Flask web interface.

### Features

- Real-time digit recognition from user input
- Deep learning model built with TensorFlow
- Simple web interface using Flask
- Image preprocessing with Pillow and NumPy

### Project Structure

```
/D:/Real Time Hand Written Digit Recognition/
│
├── static/
│   ├── example1.png
│   ├── example2.png
│   └── ... (other images)
├── templates/
│   └── index.html
├── app.py
├── model.keras
└── readme.md
```

### Example Images

Below are some example images used in this project:

![Example 1](static/image1.gif)
![Example 2](static/image2.gif)
![Example 3](static/image3.gif)

### Getting Started

1. **Install dependencies:**
    ```
    pip install flask tensorflow pillow numpy
    ```

2. **Run the Flask app:**
    ```
    python app.py
    ```

3. **Open your browser and navigate to:**
    ```
    http://localhost:5000
    ```

### Usage

- Draw a digit in the web interface or upload an image.
- The model will predict the digit in real time.

### License

This project is for educational purposes.